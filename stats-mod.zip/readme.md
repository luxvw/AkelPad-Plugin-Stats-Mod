
![Preview]{preview.png}

A modified version of AkelPad plugin "Stats" which provides more 
dedicated statistics, including counts of CJK ideographs, as well 
as several other unicode blocks.
